package com.company.realize;

import com.company.exceptions.NotEnoughMoneyException;

import java.util.Calendar;
import java.util.Date;

public class CreditCard extends DebitCard {

    private final float ACCOUNT;
    private final float percent;
    private float debt;
    private float myMoney;
    Calendar calendar = null;

    public CreditCard(String number, String bankName, String paymentSystem, String owner, String date,
                      String telNumber, int codeCVV, int pinCode, float account, float percent) {
        super(number, bankName, paymentSystem, owner, date, telNumber, codeCVV, pinCode, account);
        this.percent = percent;
        this.debt = 0;
        this.ACCOUNT = account;
        this.myMoney = 0;
    }

    //метод определения класса DebitCard - 0, а CreditCard - 1
    public int identify() { return 1; }


    public float getDebt() {
        return debt;
    }

    //метод погашения долга
    public void deposit(float money) {
        if (money >= debt) {
            myMoney = money - debt;
            account += myMoney;
            debt = 0;
            calendar = null;
        } else {
            debt -= money;
        }
    }

    // методы изменение депозита
    public void withdraw(float money) throws NotEnoughMoneyException {
        if (account < money) {
            throw new NotEnoughMoneyException("Not enough money on card's account");
        } else {
            if (myMoney - money >= 0){
                account -= money;
                myMoney -= money;
            } else {
                account -= money;
                if (calendar == null) {
                    calendar = Calendar.getInstance();
                    calendar.setTime(new Date());
                    calendar.add(Calendar.MONTH, 1);
                    debt = (1 + percent) * (money - myMoney);
                } else {
                    debt += (money - myMoney);
                }
                myMoney = 0;
            }
        }
    }

    public float getPercent() {
        return percent;
    }

    public Calendar getCalendar() {
        return calendar;
    }

    // метод обновления долга
    public void update(int n) {
        if (calendar != null) {
            calendar.add(Calendar.MONTH, n);
            debt *= percent;
        }
        account = ACCOUNT + myMoney;
    }
}
