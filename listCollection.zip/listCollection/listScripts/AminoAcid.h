#ifndef AMINOACID_H
#define AMINOACID_H

#endif // AMINOACID_H

#include <string>
#include "BaseAcid.h"

class AminoAcid : public BaseAcid {
private:

    char sign;
    char crtSign(const std::string& acid);

public:

    AminoAcid(const std::string &fullName);
    AminoAcid(const AminoAcid &aa);
    AminoAcid();
    virtual ~AminoAcid();

    void setFullName(const std::string &fullName);

    char getSign() const { return sign; }

    int indentify() const override { return 1; }
    std::string toString() const override;
};
