#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include "Collection.h"
#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_loadButt1_clicked();
    void on_loadButt2_clicked();

    void on_showButt1_clicked();

    void on_showButt2_clicked();

    void on_saveButt1_clicked();

    void on_saveButt2_clicked();

    void on_addButt1_clicked();

    void on_addButt2_clicked();

    void on_delButt1_clicked();

    void on_delButt2_clicked();

    void on_dellAllButt1_clicked();

    void on_delAllButt2_clicked();

    void on_gettButt2_clicked();

    void on_gettButt1_clicked();

    void on_countButt1_clicked();

    void on_countButt2_clicked();

    void on_sumButt_clicked();

    void on_Butt_clicked();

private:
    Ui::MainWindow *ui;
    Collection *collection1;
    Collection *collection2;

    string showCollection(const Collection &c);
    void loadCollection(Collection *c);
    void saveCollection(const Collection &c);
    void addCollection(Collection *c);
    string getElem(Collection &c);
    void delCollection(Collection *c);
    bool isEqual(const string &s);
};
#endif // MAINWINDOW_H
