В этом проекте я реализовал двухсвязный список аминокислот и графический интерфейс к нему.

In this project, I implemented a two-linked list of amino acids and a graphical interface to it.