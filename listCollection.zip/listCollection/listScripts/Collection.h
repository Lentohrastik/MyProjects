#ifndef COLLECTION_H
#define COLLECTION_H

#endif // COLLECTION_H

#include <iostream>
#include "AminoAcid.h"
using namespace std;


class Collection {
private:

    struct Acid {
        BaseAcid *acid;
        Acid *next;
        Acid *prev;
        Acid(const string &str) :
            next(nullptr), prev(nullptr){
            if (AminoAcid(str).getSign() == '0') {
                acid = new BaseAcid(str);
            } else {
                acid = new AminoAcid(str);
            }
        }

        Acid(BaseAcid *d) :
            acid(d), next(nullptr), prev(nullptr){}
        ~Acid() {
            delete acid;
        }
    };

    Acid *head;
    Acid *tail;

public:

    class Iterator {
    private:
        Acid* cur;
    public:
        Iterator(Acid* first) {
            cur = first;
        }
        Acid* operator* () { return cur; }

        bool operator!= (const Iterator& it) { return cur != it.cur; }
        bool operator== (const Iterator& it) { return cur == it.cur; }
        void operator++ (int) { if (cur) cur = cur->next; }
        void operator-- (int) { if (cur) cur = cur->prev; }
    };


    Collection();
    Collection(const Collection& c);
    ~Collection();

    void add(BaseAcid *d);
    void del(int pos);
    void delAll();

    BaseAcid& get(int pos) const;
    int getCount();

    //file methods
    void readFile(const string &path);
    void writeFile(const string &path) const;

    //my method
    Collection *operator+(const Collection &c);

    // iterator methods
    Iterator getHeadIter() const { return Iterator(head); }
    Iterator getTailIter() const { return Iterator(tail); }
};
