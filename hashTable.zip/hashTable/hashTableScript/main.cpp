#include "mainwindow.h"
#include <iostream>
#include <assert.h>

#include <QApplication>

int main(int argc, char *argv[])
{
    /*//проверка конструктора по умолчанию
    Collection<string, string> *c = new Collection<string, string>();
    assert(c->getCount() == 0);

    //проверка удаления всех элементов
    Collection <string, string> *c1 = new Collection<string, string>();
    c1->readFile("D:/Leo/QT_Projects/10.txt");
    assert(c1->getCount() > 0);
    c1->delAll();
    assert(*c == *c1);

    //проверка чтения и записи в файл
    c->readFile("D:/Leo/QT_Projects/10.txt");
    c->writeFile("D:/Leo/QT_Projects/11.txt");
    c1->readFile("D:/Leo/QT_Projects/11.txt");
    assert(*c == *c1);

    //проверка метода add
    int len1 = c->getCount();
    c->add("gjgj", "12");
    int len2 = c->getCount();
    assert(len1 + 1 == len2);
    c->add("aaaa", "345");
    len1 = c->getCount();
    assert(len1 == len2);

    //проверка метода isExist
    assert(c->isExist("aaaa"));
    assert(!c->isExist("fjfjfjfjffjfj"));
    //проверка оператора[]
    assert(*(*c)["aaaa"] == "345");
    //assert((*c)["fjfjfjffj"] == nullptr);

    //проверка метода del
    len1 = c->getCount();
    c->del("fjfjfjfjfjfjfj");
    len2 = c->getCount();
    assert(len1 == len2);
    c->del("aaaa");
    len2 = c->getCount();
    assert(len1 = len2 + 1);

    //проверка конструктора копирования
    Collection <string, string> *c2 = new Collection<string, string>(*c);
    assert(*c == *c2);
    c2->add("wwww", "666");
    assert(!(*c == *c2));

    delete c;
    delete c1;
    delete c2;


    cout << "Good!!!" << endl;*/
    QApplication a(argc, argv);
    MainWindow w;
    w.show();
    return a.exec();

}
