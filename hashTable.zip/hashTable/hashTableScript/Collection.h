#ifndef COLLECTION_H
#define COLLECTION_H
#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

template <typename K, typename V> class Collection {
private:
    const static int len = 256;
    struct KeyValue {
        K key;
        V value;
        KeyValue *next;
        KeyValue(const K &k, const V &v) {
            key = k;
            value = v;
            next = nullptr;
        }
        KeyValue(const KeyValue &kv) {
            key = kv.key;
            value = kv.value;
            next = nullptr;
        }
        bool operator== (const KeyValue &kv) {
            return key == kv.key && value == kv.value;
        }
    };
    int count;
    KeyValue *arr[len];

    int hash(const K &key) const {
        string str = key;
        int sum = 0;
        for (auto i = 0; i < str.length(); i++) {
            sum += (int)str[i];
        }
        return int(sum/str.length());
    }

public:
    Collection() :
        count(0) {
        for (auto i = 0; i < len; i++) arr[i] = nullptr;
    }

    Collection(const Collection &c) :
        count(c.getCount()) {
        for (auto i = 0; i < len; i++) {
            if (c.arr[i]) {
                arr[i] = new KeyValue(*c.arr[i]);
                KeyValue *cur1 = arr[i], *cur2 = c.arr[i]->next, *prev = cur1;
                while(cur2) {
                    cur1 = new KeyValue(*cur2);
                    prev->next = cur1;
                    prev = cur1;
                    cur2 = cur2->next;
                }
            } else
                arr[i] = nullptr;
        }
    }

    ~Collection() { delAll(); }

    void delAll() {
        for (auto i = 0; i < len; i++) {
            if (arr[i]) {
                KeyValue *cur = arr[i];
                arr[i] = nullptr;
                while(cur) {
                    KeyValue *next = cur->next;
                    delete cur;
                    count--;
                    cur = next;
                }
            }
        }
    }

    void del(const K &key) {
        int i = hash(key);
        if (arr[i]) {
            KeyValue *cur = arr[i], *prev;
            while(cur) {
                if (cur->key == key){
                    if (cur == arr[i]) {
                        arr[i] = cur->next;
                        delete cur;
                        cur = nullptr;
                        count--;
                    } else {
                        prev->next = cur->next;
                        delete cur;
                        cur = nullptr;
                        count--;
                    }
                } else {
                    cout << 4 << endl;
                    prev = cur;
                    cur = cur->next;
                }
            }
        }
    }

    void add (const K &key, const V &value) {
        int i = hash(key);
        if (arr[i]) {
            KeyValue *cur = arr[i];
            while(cur->next && cur->key != key)
                cur = cur->next;
            if (cur->next) {
                cur->value = value;
            } else if (cur->key == key) {
                cur->value = value;
            } else {
                KeyValue *p = new KeyValue(key, value);
                cur->next = p;
                count++;
            }
        } else {
            arr[i] = new KeyValue(key, value);
            count++;
        }
    }

    vector<V> get(vector<K> keys) const {
        vector<V> values;
        for (auto i = 0; i < keys.size(); i++) {
            V *value =(*this)[keys[i]];
            if (value) {
                values.push_back(*value);
            } else {
                values.push_back(V("-"));
            }
        }
        return values;
    }

    void writeFile(const string &path) const {
        ofstream fout;
        fout.open(path);
        if (fout.is_open()) {
            for (auto i = 0; i < len; i++) {
                KeyValue *cur = arr[i];
                while (cur) {
                    fout << cur->key << " " << cur->value << endl;
                    cur = cur->next;
                }
            }
        } else
            throw exception();
        fout.close();
    }

    void readFile(const string &path) {
        delAll();
        ifstream fin;
        fin.open(path);
        if (fin.is_open()) {
            while(!fin.eof()) {
                string str1, str2;
                fin >> str1 >> str2;
                if (str2 == "") break;
                K key = K(str1);
                V value = V(str2);
                add(key, value);
            }
        } else
            throw exception();
        fin.close();
    }

    bool isExist(const K &key) const {
        int i = hash(key);
        KeyValue *cur = arr[i];
        while(cur) {
            if (cur->key == key)
                return true;
            cur = cur->next;
        }
        return false;
    }

    int getCount() const { return count; }

    V *operator[] (const K &key) const {
        int i = hash(key);
        KeyValue *cur = arr[i];
        while(cur) {
            if (cur->key == key)
                return new V(cur->value);
            cur = cur->next;
        }
        return nullptr;
    }

    bool operator== (const Collection &c) const {
        for (auto i = 0; i < len; i++) {
            if ((arr[i] && !c.arr[i]) || (!arr[i] && c.arr[i]))
                return false;
            else if (arr[i] && c.arr[i]) {
                KeyValue *cur1 = arr[i], *cur2 = c.arr[i];
                while (cur1 && cur2 && *cur1 == *cur2) {
                    cur1 = cur1->next;
                    cur2 = cur2->next;
                }
                if (cur1 || cur2)
                    return false;
            }
        }
        return true;
    }

    vector<string> show() const {
        vector<K> items;
        for (auto i = 0; i < len; i++) {
            if (arr[i]) {
                KeyValue *cur = arr[i];
                while(cur) {
                    items.push_back(cur->key);
                    cur = cur->next;
                }
            }
        }
        return items;
    }

    bool isEmpty() const {
        if(count == 0)
            return true;
        return false;
    }


};

#endif // COLLECTION_H
