package com.company.exceptions;

public class IncorrectSumException extends Exception {
    public IncorrectSumException(String message) {
        super(message);
    }
}
