#include <QApplication>

#include "mainwindow.h"
#include <iostream>
#include <assert.h>

int main(int argc, char *argv[])
{
    BaseAcid *b = new BaseAcid();
    assert(b->getFullName() == "");

    b->setFullName("Selenocysteine");
    assert(b->getFullName() == "Selenocysteine");

    BaseAcid *b1 = new BaseAcid("Selenocysteine");
    assert(b1->getFullName() == "Selenocysteine");

    BaseAcid *b2 = new BaseAcid(*b1);
    assert(b2->getFullName() == b1->getFullName());

    cout << b2->getFullName() << endl;
    delete b;
    delete b1;
    delete b2;

    QApplication a(argc, argv);
    MainWindow w;
    w.show();
    return a.exec();
}
