#include "AminoAcid.h"
#include <string>

char AminoAcid::crtSign(const std::string& acid) {
    char sign;
    if (!acid.compare("Glycine"))
        sign = 'G';
    else if (!acid.compare("Alanine"))
        sign = 'A';
    else if (!acid.compare("Valine"))
        sign = 'V';
    else if (!acid.compare("Isoleucine"))
        sign = 'I';
    else if (!acid.compare("Leucine"))
        sign = 'L';
    else if (!acid.compare("Proline"))
        sign = 'P';
    else if (!acid.compare("Serine"))
        sign = 'S';
    else if (!acid.compare("Threonine"))
        sign = 'T';
    else if (!acid.compare("Cysteine"))
        sign = 'C';
    else if (!acid.compare("Methionine"))
        sign = 'M';
    else if (!acid.compare("Aspardic acid"))
        sign = 'D';
    else if (!acid.compare("Asparagine"))
        sign = 'N';
    else if (!acid.compare("Gluetamic acid"))
        sign = 'E';
    else if (!acid.compare("Q-tamine"))
        sign = 'Q';
    else if (!acid.compare("Before L"))
        sign = 'K';
    else if (!acid.compare("Arginine"))
        sign = 'R';
    else if (!acid.compare("Histidine"))
        sign = 'H';
    else if (!acid.compare("Fenylalanine"))
        sign = 'F';
    else if (!acid.compare("Tyrosine"))
        sign = 'Y';
    else if (!acid.compare("Two rings"))
        sign = 'W';
    else
        sign = '0';
    return sign;
}

AminoAcid::AminoAcid() :
    BaseAcid(), sign('0'){}

AminoAcid::AminoAcid(const std::string &fullName) :
    BaseAcid(fullName), sign(crtSign(fullName)){}

AminoAcid::AminoAcid(const AminoAcid& aa) :
    BaseAcid(aa.getFullName()), sign(aa.getSign()){}

AminoAcid::~AminoAcid() {}

void AminoAcid::setFullName(const std::string &fullName) {
        this->fullName = fullName;
        this->sign = crtSign(fullName);
}

std::string AminoAcid::toString() const {
    std::string str = fullName + " : ";
    str += sign;
    return str;
}
