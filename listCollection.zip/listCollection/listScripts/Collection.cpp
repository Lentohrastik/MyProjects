#include "Collection.h"
#include <iostream>
#include <fstream>
using namespace std;

Collection::Collection() :
    head(nullptr), tail(nullptr) {}

Collection::Collection(const Collection &c) {
    if (*c.getHeadIter()) {
        if (head) delAll();
        Iterator iter = c.getHeadIter();
        Acid *cur;
        if ((*iter)->acid->indentify() == 0)
            cur = new Acid(new BaseAcid((*iter)->acid->getFullName()));
        else
            cur = new Acid(new AminoAcid((*iter)->acid->getFullName()));
        head = cur;
        Acid* prev = cur;
        cur->prev = nullptr;
        iter++;
        while (*iter) {
            if (iter == *c.getTailIter()) {
                if ((*iter)->acid->indentify() == 0)
                    cur = new Acid(new BaseAcid((*iter)->acid->getFullName()));
                else
                    cur = new Acid(new AminoAcid((*iter)->acid->getFullName()));
                prev->next = cur;
                cur->prev = prev;
                cur->next = nullptr;
                tail = cur;
            }
            else {
                if ((*iter)->acid->indentify() == 0)
                    cur = new Acid(new BaseAcid((*iter)->acid->getFullName()));
                else
                    cur = new Acid(new AminoAcid((*iter)->acid->getFullName()));
                prev->next = cur;
                cur->prev = prev;
                prev = cur;
            }
            iter++;
        }
    }
}

Collection::~Collection() {
    delAll();
}

void Collection::add(BaseAcid *d) {
    if (head) {
        Acid* p = new Acid(d);
        tail->next = p;
        p->prev = tail;
        p->next = nullptr;
        tail = p;
    }
    else {
        Acid* p = new Acid(d);
        head = p;
        head->prev = nullptr;
        head->next = nullptr;
        tail = p;
    }

}

void Collection::del(int pos) {
    Iterator iter = getHeadIter();
    for (auto i = 0; i < pos && *iter; i++, iter++);
    if (*iter) {
        if (tail == head) {
            delete* iter;
            tail = nullptr;
            head = nullptr;
        }
        else if (*iter == head) {
            head = (*iter)->next;
            head->prev = nullptr;
            delete* iter;
        }
        else if (*iter == tail) {
            tail = (*iter)->prev;
            tail->next = nullptr;
            delete *iter;
        } else {
            (*iter)->next->prev = (*iter)->prev;
            (*iter)->prev->next = (*iter)->next;
            delete* iter;
        }
    }
}

void Collection::delAll() {
    if (tail) {
        Iterator iter = getTailIter();
        iter--;
        while (*iter) {
            delete tail;
            tail = *iter;
            iter--;
        }
        delete tail;
        tail = *iter;
    }
    head = nullptr;
    tail = nullptr;
}

BaseAcid& Collection::get(int pos) const {
    Iterator iter = getHeadIter();
    for (auto i = 0; i < pos && *iter; i++, iter++);
    if (*iter) {
        return *(*iter)->acid;
    }
    cout << "Wrong index!\n";
    return *head->acid;
}

int Collection::getCount() {
    int count = 0;
    if (head) {
        Iterator iter = getHeadIter();
        while (*iter) {
            count++;
            iter++;
        }
    }
    return count;
}

void Collection::readFile(const string& path) {
    if (head) delAll();
    ifstream fin;
    fin.open(path);
    if (fin.is_open()) {
        string str;
        Acid *cur, *prev;
        if (!fin.eof()) {
            getline(fin, str);
            cur = new Acid(str);
            head = cur;
            prev = cur;
            while (!fin.eof()) {
                getline(fin, str);
                if (str != "") {
                    cur = new Acid(str);
                    prev->next = cur;
                    cur->prev = prev;
                    prev = cur;
                }
            }
            tail = cur;
        }
    }
    else
        throw exception();
    fin.close();
}

void Collection::writeFile(const string& path) const {
    if (head) {
        ofstream fout;
        fout.open(path);
        if (fout.is_open()) {
            Iterator iter = getHeadIter();
            while (*iter) {
                fout << (*iter)->acid->getFullName() << endl;
                iter++;
            }
        }
        else {
            throw exception();
        }
        fout.close();
    }
}

Collection *Collection::operator+(const Collection &c) {
    Collection *first = new Collection(*this);
    Collection *second = new Collection(c);
    Iterator iter1 = first->getHeadIter();
    Iterator iter2 = second->getHeadIter();
    int flag = 0;
    while ((*iter1)) {
        if ((*iter1)->acid->getFullName() == (*iter2)->acid->getFullName()) {
            Iterator iter11 = Iterator((*iter1)->next);
            iter2++;
            while (*iter11 && *iter2 && (*iter11)->acid->getFullName() == (*iter2)->acid->getFullName()) {
                iter11++;
                iter2++;
            }
            if (*iter11 || iter2 == second->getHeadIter()) {
                iter2 = second->getHeadIter();
                iter1++;
            } else if (!*iter11) {
                if (*iter2) {
                    flag = 2;
                    iter1 = iter11;
                } else {
                    flag = 1;
                    iter1 = iter11;
                }
            }
        } else {
            iter1++;
        }
    }
    if (flag == 2) {
        (*first->getTailIter())->next = *iter2;
        Acid *c = (*iter2)->prev;
        (*iter2)->prev = *first->getTailIter();
        first->tail = second->tail;
        second->tail = c;
        delete second;
        return first;
    } else if (flag == 1) {
        delete second;
        return first;
    } else {
        delete first;
        delete second;
        return nullptr;
    }
}
