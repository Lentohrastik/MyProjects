#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

#include "Collection.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_loadButt_clicked();

    void on_saveButt_clicked();

    void on_addButt_clicked();

    void on_delButt_clicked();

    void on_pushButton_clicked();

    void on_delAllButt_clicked();

private:
    Ui::MainWindow *ui;
    Collection<string, string> *collection;

    void shw();
};
#endif // MAINWINDOW_H
