package com.company.windows;

import com.company.exceptions.NotEnoughMoneyException;
import com.company.realize.CreditCard;
import com.company.realize.DebitCard;


import javax.swing.*;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;
import javax.swing.text.PlainDocument;
import java.awt.*;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.util.Calendar;
import java.util.Date;


public class CardTransferWindow extends JFrame {
    public CardTransferWindow(String title, DebitCard card, MainWindow mainWindow){
        super(title);
        setBounds(600, 250, 375, 350);
        addWindowListener(new WindowListener() {
            @Override
            public void windowOpened(WindowEvent e) {

            }

            @Override
            public void windowClosing(WindowEvent e) {
                mainWindow.setVisible(true);
                dispose();
            }

            @Override
            public void windowClosed(WindowEvent e) {

            }

            @Override
            public void windowIconified(WindowEvent e) {

            }

            @Override
            public void windowDeiconified(WindowEvent e) {

            }

            @Override
            public void windowActivated(WindowEvent e) {

            }

            @Override
            public void windowDeactivated(WindowEvent e) {

            }
        });
        setLayout(new BorderLayout());
        setResizable(false);

        JLabel number = new JLabel("Введите номер карты");
        number.setFont(new Font("TimesRoman", Font.BOLD, 20));

        JTextField first4 = new JTextField(4);
        JTextField second4 = new JTextField(4);
        JTextField third4 = new JTextField(4);
        JTextField fourth4 = new JTextField(4);

        JLabel sum = new JLabel("Введите сумму денег");
        sum.setFont(new Font("TimesRoman", Font.BOLD, 20));

        JTextField inputSum = new JTextField(10);

        JButton submit = new JButton("Перевести");
        submit.setFocusable(false);
        submit.setPreferredSize(new Dimension(150,30));
        submit.setFocusable(false);
        submit.setFocusPainted(false);
        submit.setFont(new Font("TimesRoman", Font.BOLD, 15));
        submit.setFocusable(false);

        PlainDocument document1 = (PlainDocument) first4.getDocument();
        PlainDocument document2 = (PlainDocument) second4.getDocument();
        PlainDocument document3 = (PlainDocument) third4.getDocument();
        PlainDocument document4 = (PlainDocument) fourth4.getDocument();
        DocumentFilter filter = new DocumentFilter(){
            @Override
            public void replace(DocumentFilter.FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
                String string = fb.getDocument().getText(0, fb.getDocument().getLength()) + text;

                if (string.length() <= 4 && isDigit(string)) {
                    super.replace(fb, offset, length, text, attrs); //To change body of generated methods, choose Tools | Templates.
                }
            }
        };
        document1.setDocumentFilter(filter);
        document2.setDocumentFilter(filter);
        document3.setDocumentFilter(filter);
        document4.setDocumentFilter(filter);

        PlainDocument document5 = (PlainDocument) inputSum.getDocument();
        DocumentFilter filter1 = new DocumentFilter(){
            @Override
            public void replace(DocumentFilter.FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
                String string = fb.getDocument().getText(0, fb.getDocument().getLength()) + text;

                if (isFloat(string)) {
                    super.replace(fb, offset, length, text, attrs); //To change body of generated methods, choose Tools | Templates.
                }
            }
        };
        document5.setDocumentFilter(filter1);

        submit.addActionListener(e -> {
            String number1 = first4.getText() + " " + second4.getText() + " " + third4.getText() + " " + fourth4.getText();
            if (number1.length() < 19) {
                JOptionPane.showMessageDialog(getMe(), "Заполните все поля!",
                        "Предупреждение", JOptionPane.WARNING_MESSAGE);
            } else {
                DebitCard secondCard = mainWindow.getStartWindow().getAtm().getCardByNumber(number1);
                if (secondCard == null) {
                    JOptionPane.showMessageDialog(getMe(), "Такой карты не существует",
                            "Ошибка", JOptionPane.ERROR_MESSAGE);
                } else {
                    if (secondCard.identify() == 1){
                        CreditCard creditCard = (CreditCard) secondCard;
                        if (creditCard.getCalendar() != null) {
                            Calendar calendar = Calendar.getInstance();
                            calendar.setTime(new Date());
                            int n = (int) ((calendar.getTimeInMillis()
                                    - creditCard.getCalendar().getTimeInMillis()) /
                                    (60000 * 1440 * 30));
                            creditCard.update(n);
                        }
                    }
                    if (secondCard.getNumber().equals(card.getNumber())) {
                        JOptionPane.showMessageDialog(getMe(), "Нельзя перевести на ту же карту!",
                                "Предупреждение", JOptionPane.WARNING_MESSAGE);
                    }
                    else if (inputSum.getText().equals("")) {
                        JOptionPane.showMessageDialog(getMe(), "Вы ничего не ввели!",
                                "Предупреждение", JOptionPane.WARNING_MESSAGE);
                    }else {
                        try {
                            card.withdraw(Float.parseFloat(inputSum.getText()));
                            secondCard.deposit(Float.parseFloat(inputSum.getText()));
                            mainWindow.getStartWindow().getAtm().incNum();
                            JOptionPane.showMessageDialog(getMe(),
                                    mainWindow.getStartWindow().getAtm().getCheque(card,
                                            Float.parseFloat(inputSum.getText()), 2));
                            mainWindow.setVisible(true);
                            dispose();
                        } catch (NotEnoughMoneyException ignored) {
                            JOptionPane.showMessageDialog(getMe(), "На карте недостаточно средств!",
                                    "Ошибка", JOptionPane.ERROR_MESSAGE);
                            inputSum.setText("");
                        }
                    }
                }
            }
        });

        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(20, 0, 0, 0);
        c.gridx = 0;
        c.gridy = 0;
        panel.add(number, c);
        c.gridx = 0;
        c.gridy = 1;

        JPanel panel1 = new JPanel();
        panel1.setLayout(new GridBagLayout());
        GridBagConstraints c1 = new GridBagConstraints();
        c1.insets = new Insets(20, 0,0,20);
        c1.gridx = 0;
        c1.gridy = 0;
        panel1.add(first4, c1);
        c1.gridx = 1;
        c1.gridy = 0;
        panel1.add(second4, c1);
        c1.gridx = 2;
        c1.gridy = 0;
        panel1.add(third4, c1);
        c1.insets = new Insets(20, 0,0,0);
        c1.gridx = 3;
        c1.gridy = 0;
        panel1.add(fourth4, c1);
        panel.add(panel1, c);

        c.gridx = 0;
        c.gridy = 2;
        panel.add(sum, c);
        c.gridx = 0;
        c.gridy = 3;
        panel.add(inputSum, c);
        c.gridx = 0;
        c.gridy = 4;
        panel.add(submit, c);

        add(panel);
        setVisible(true);
    }
    private boolean isDigit(String str){
        try{
            Integer.parseInt(str);
            return true;
        }
        catch (Exception e){
            return false;
        }
    }
    private boolean isFloat(String str){
        try{
            Float.parseFloat(str);
            return true;
        }
        catch (Exception e){
            return false;
        }
    }
    private CardTransferWindow getMe(){
        return this;
    }
}
