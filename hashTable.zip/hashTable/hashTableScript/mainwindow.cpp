#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include <QFileDialog>
#include <sstream>
#include <QTableWidgetItem>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , collection(new Collection<string, string>()) {
    ui->setupUi(this);
    ui->delAllButt->setEnabled(false);
    ui->delButt->setEnabled(false);
}

MainWindow::~MainWindow() {
    delete ui;
    delete collection;
}

void MainWindow::shw() {
    ui->table->clear();
    ui->table->setRowCount(collection->getCount());
    ui->table->setColumnCount(2);
    QStringList name_table;
    name_table << "Key" << "Value";
    ui->table->setHorizontalHeaderLabels(name_table);
    vector<string> keys = collection->show();
    for (auto i = 0; i < keys.size(); i++) {
        ui->table->setItem(i, 0, new QTableWidgetItem(QString::fromStdString(keys[i])));
        ui->table->setItem(i, 1, new QTableWidgetItem(QString::fromStdString(*(*collection)[keys[i]])));
    }
}


void MainWindow::on_loadButt_clicked() {
    string path = QFileDialog::getOpenFileName().toStdString();
    if (path == "") {
        QMessageBox::warning(this, "Предупреждение", "Вы ничего не выбрали!");
    } else {
        try {
           collection->readFile(path);
           shw();
           ui->delAllButt->setEnabled(true);
           ui->delButt->setEnabled(true);
           if (collection->isEmpty()){
               ui->delAllButt->setEnabled(false);
               ui->delButt->setEnabled(false);
           }
        }
        catch (exception e) {
            QMessageBox::warning(this, "Предупреждение", "Не удалось открыть файл!");
        }
    }
}


void MainWindow::on_saveButt_clicked() {
    string path = QFileDialog::getOpenFileName().toStdString();
    if (path == "") {
        QMessageBox::warning(this, "Предупреждение", "Вы не выбрли файл!");
    } else {
        try {
           collection->writeFile(path);
        }
        catch (exception e) {
            QMessageBox::warning(this, "Предупреждение", "Не удалось открыть файл!");
        }
    }
}


void MainWindow::on_addButt_clicked() {
    string strKey = ui->lineEditKey->text().toStdString();
    string strValue = ui->lineEditValue->text().toStdString();
    if (strKey == "" || strValue == "") {
        QMessageBox::warning(this, "Предупреждение", "Заполните поля!");
    } else {
        collection->add(strKey, strValue);
        shw();
        ui->delAllButt->setEnabled(true);
        ui->delButt->setEnabled(true);
    }
    ui->lineEditKey->clear();
    ui->lineEditValue->clear();
}


void MainWindow::on_delButt_clicked() {
    string strKey = ui->lineEditDelKey->text().toStdString();
    if (strKey == "") {
        QMessageBox::warning(this, "Предупреждение", "Вы ничего не ввели!");
    } else {
        if (collection->isExist(strKey)) {
            collection->del(strKey);
            shw();
            if (collection->isEmpty()) {
                ui->delAllButt->setEnabled(false);
                ui->delButt->setEnabled(false);
            }
        } else {
            QMessageBox::warning(this, "Предупреждение", "Нет такого ключа!");
        }
        ui->lineEditDelKey->clear();
    }
}


void MainWindow::on_pushButton_clicked() {
    string strKeys = ui->lineEditGetKeys->text().toStdString();
    if (strKeys != "") {
        istringstream iss(strKeys);
        string str;
        vector<string> keys;
        while(iss) {
            iss >> str;
            keys.push_back(str);
        }
        vector<string> values = collection->get(keys);
        str = "";
        for (auto i = 0; i < values.size() - 2; i++) {
            str += (values[i] + ", ");
        }
        str += values[values.size() - 2];
        ui->getLabel->setText(QString::fromStdString(str));
    } else {
        QMessageBox::warning(this, "Предупреждение", "Вы ничего не ввели!");
    }
}


void MainWindow::on_delAllButt_clicked() {
    collection->delAll();
    shw();
    ui->delAllButt->setEnabled(false);
    ui->delButt->setEnabled(false);
}

