package com.company.windows;

import com.company.realize.DebitCard;

import javax.swing.*;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;
import javax.swing.text.PlainDocument;
import java.awt.*;

import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

public class PinWindow extends JFrame {
    public PinWindow(String title, StartWindow frame, DebitCard card){
        super(title);
        frame.setVisible(false);
        setBounds(600, 250, 350, 300);
        addWindowListener(new WindowListener() {
            @Override
            public void windowOpened(WindowEvent e) {

            }

            @Override
            public void windowClosing(WindowEvent e) {
                frame.setVisible(true);
                dispose();
            }

            @Override
            public void windowClosed(WindowEvent e) {

            }

            @Override
            public void windowIconified(WindowEvent e) {

            }

            @Override
            public void windowDeiconified(WindowEvent e) {

            }

            @Override
            public void windowActivated(WindowEvent e) {

            }

            @Override
            public void windowDeactivated(WindowEvent e) {

            }
        });
        setLayout(new BorderLayout());
        setResizable(false);

        JPasswordField pinCode = new JPasswordField(4);
        JLabel startText = new JLabel("Введите ПИН-КОД");
        startText.setFont(new Font("TimesRoman", Font.BOLD, 20));
        pinCode.setBorder(javax.swing.BorderFactory.createEmptyBorder());
        pinCode.setBackground(new java.awt.Color(240,240,240));
        pinCode.setEchoChar('✸');

        PlainDocument document = (PlainDocument) pinCode.getDocument();
        document.setDocumentFilter(new DocumentFilter() {

            @Override
            public void replace(DocumentFilter.FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
                String string = fb.getDocument().getText(0, fb.getDocument().getLength()) + text;

                if (string.length() <= 4 && isDigit(string)) {
                    super.replace(fb, offset, length, text, attrs); //To change body of generated methods, choose Tools | Templates.
                }
            }
        });

        pinCode.addActionListener(e -> {
            if ((new String(pinCode.getPassword())).length() < 4) {
                System.err.println("Вы не ввели ПИН-КОД");
                JOptionPane.showMessageDialog(getMe(),"ПИН-КОД состоит из 4 цифр!", "Предупреждение", JOptionPane.WARNING_MESSAGE);
            }
            else{
                if (!new String(pinCode.getPassword()).equals(card.getPinCode() + "")){
                    JOptionPane.showMessageDialog(getMe(),"Неверный ПИН-КОД!", "Предупреждение", JOptionPane.ERROR_MESSAGE);
                }
                else{
                    new MainWindow("Главное меню", card, frame);
                    getMe().dispose();
                }
            }
        });

        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(-20, 0, 0 ,0);
        c.gridx = 0;
        c.gridy = 0;
        panel.add(startText, c);
        c.insets = new Insets(20,5,0,0);
        c.gridx = 0;
        c.gridy = 1;
        panel.add(pinCode, c);
        add(panel);

        setVisible(true);
    }
    private boolean isDigit(String str){
        try{
            Integer.parseInt(str);
            return true;
        }
        catch (Exception e){
            return false;
        }
    }
    private PinWindow getMe(){
        return this;
    }
}
