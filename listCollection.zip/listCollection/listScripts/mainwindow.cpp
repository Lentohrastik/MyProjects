#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include <QFileDialog>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , collection1(new Collection())
    , collection2(new Collection())
{
    ui->setupUi(this);
}

MainWindow::~MainWindow() {
    delete ui;
    delete collection1;
    delete collection2;
}

bool MainWindow::isEqual(const string &s) {
    Collection *c = new Collection();
    c->readFile("D:/Leo/QT_Projects/5.txt");
    string str = showCollection(*c);
    delete c;
    return s == str;

}

string MainWindow::showCollection(const Collection& c) {
    Collection::Iterator iter = c.getHeadIter();
    int count = 0;
    string str = "";
    while (*iter) {
        str += (*iter)->acid->toString();
        str += " : ";
        str += to_string(count);
        str += '\n';
        iter++;
        count++;
    }
    return str;
}

void MainWindow::loadCollection(Collection *c) {
    string path = QFileDialog::getOpenFileName().toStdString();
    if (path == "") {
        QMessageBox::warning(this, "Предупреждение", "Вы ничего не ввели!");
    } else {
        try {
           c->readFile(path);
        }
        catch (exception e) {
            QMessageBox::warning(this, "Предупреждение", "Неверный путь к файлу, или не удалось открыть файл!");
        }
    }
}

void MainWindow::saveCollection(const Collection &c) {
    string path = QFileDialog::getOpenFileName().toStdString();
    if (path == "") {
        QMessageBox::warning(this, "Предупреждение", "Вы ничего не ввели!");
    } else {
        try {
           c.writeFile(path);
        }
        catch (exception e) {
            QMessageBox::warning(this, "Предупреждение", "Неверный путь к файлу, или не удалось открыть файл!");
        }
    }
}

void MainWindow::addCollection(Collection *c) {
    string str = ui->lineEditAdd->text().toStdString();
    if (str == "") {
        QMessageBox::warning(this, "Предупреждение", "Вы ничего не ввели!");
    } else {
        if (AminoAcid(str).getSign() == '0')
            c->add(new BaseAcid(str));
        else
            c->add(new AminoAcid(str));
        ui->lineEditAdd->clear();
    }
}

void MainWindow::delCollection(Collection *c) {
    int pos = stoi(ui->lineEditDel->text().toStdString());
    if (pos < 0 || pos >= c->getCount()) {
        QMessageBox::warning(this, "Предупреждение", "Такого элемента нет!");
    } else {
        c->del(pos);
        ui->lineEditDel->clear();
    }

}

string MainWindow::getElem(Collection &c) {
    int pos = stoi(ui->lineEditGet->text().toStdString());
    if (pos >= c.getCount() || pos < 0) {
        QMessageBox::warning(this, "Предупреждение", "Такого элемента нет!");
        return "";
    } else {
        string str = c.get(pos).toString() + " : " + to_string(pos);
        return str;
    }
}

void MainWindow::on_loadButt1_clicked() {
    loadCollection(collection1);
    on_showButt1_clicked();
}

void MainWindow::on_loadButt2_clicked() {
    loadCollection(collection2);
    on_showButt2_clicked();
}

void MainWindow::on_showButt1_clicked() {
    string str = showCollection(*collection1);
    ui->textBrowser1->setText(QString::fromStdString(str));
}


void MainWindow::on_showButt2_clicked() {
    string str = showCollection(*collection2);
    ui->textBrowser2->setText(QString::fromStdString(str));
}



void MainWindow::on_saveButt1_clicked() {
    saveCollection(*collection1);
}


void MainWindow::on_saveButt2_clicked() {
    saveCollection(*collection2);
}


void MainWindow::on_addButt1_clicked() {
    addCollection(collection1);
    on_showButt1_clicked();
}


void MainWindow::on_addButt2_clicked() {
    addCollection(collection2);
    on_showButt2_clicked();
}

void MainWindow::on_delButt1_clicked() {
    delCollection(collection1);
    on_showButt1_clicked();
}


void MainWindow::on_delButt2_clicked() {
    delCollection(collection2);
    on_showButt2_clicked();
}


void MainWindow::on_dellAllButt1_clicked() {
    collection1->delAll();
    on_showButt1_clicked();
}


void MainWindow::on_delAllButt2_clicked() {
    collection2->delAll();
    on_showButt2_clicked();
}


void MainWindow::on_gettButt1_clicked() {
    if (ui->lineEditGet->text().toStdString() == ""){
        QMessageBox::warning(this, "Предупреждение", "Вы ничего не ввели!");
    } else {
        string str = getElem(*collection1);
        if (str != "") {
            ui->getLable->setText(QString::fromStdString("Элемент: " + str));
        }
        ui->lineEditGet->clear();
    }
}


void MainWindow::on_gettButt2_clicked() {
    if (ui->lineEditGet->text().toStdString() == ""){
        QMessageBox::warning(this, "Предупреждение", "Вы ничего не ввели!");
    } else {
        string str = getElem(*collection2);
        if (str != "") {
            ui->getLable->setText(QString::fromStdString("Элемент: " + str));
        }
        ui->lineEditGet->clear();
    }
}


void MainWindow::on_countButt1_clicked() {
    ui->countLable->setText(QString::fromStdString("Количество элементов: " + to_string(collection1->getCount())));
}


void MainWindow::on_countButt2_clicked() {
    ui->countLable->setText(QString::fromStdString("Количество элементов: " + to_string(collection2->getCount())));
}


void MainWindow::on_sumButt_clicked() {
    string str;
    Collection *c = *collection1 + *collection2;
    if (c) {
        str = showCollection(*c);
    } else QMessageBox::warning(this, "Предупреждение", "Данные коллекции нельзя сложить!");
    ui->textBrowser3->setText(QString::fromStdString(str));
    if (isEqual(str)) {
        QMessageBox::warning(this, "Предупреждение", "Тест с суммой пройден!");
    }
}

void MainWindow::on_Butt_clicked() {
    try {
        string path = QFileDialog::getOpenFileName().toStdString(), str;
        Collection *c = *collection1 + *collection2;
        if (c) {
            str = showCollection(*c);
            ui->textBrowser3->setText(QString::fromStdString(str));
            c->writeFile(path);
        }
    }  catch (exception e) {
        QMessageBox::warning(this, "Предупреждение", "Вы ничего не выбрали, или файл недоступен!");
    }
}

