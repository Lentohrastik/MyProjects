#ifndef BASEACID_H
#define BASEACID_H

#endif // BASEACID_H

#include <string>

class BaseAcid {
protected:

    std::string fullName;

public:

    BaseAcid(const std::string &fullName);
    BaseAcid(const BaseAcid &aa);
    BaseAcid();
    virtual ~BaseAcid();

    void setFullName(const std::string &fullName);

    std::string getFullName() const { return fullName; }

    virtual int indentify() const { return 0; }
    virtual std::string toString() const;
};
