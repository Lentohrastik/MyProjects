В этом проекте я реализовал хеш-таблицу(string, int) и графический интерфейс к ней.

In this project, I implemented a hash table (string, int) and a graphical interface to it.