#ifndef BASEACID_CPP
#define BASEACID_CPP

#endif // BASEACID_CPP

#include "BaseAcid.h"
#include <string>

BaseAcid::BaseAcid() :
    fullName("") {}

BaseAcid::BaseAcid(const std::string &fullName) :
    fullName(fullName){}

BaseAcid::BaseAcid(const BaseAcid& aa) :
    fullName(aa.getFullName()) {}

BaseAcid::~BaseAcid() {}

void BaseAcid::setFullName(const std::string &fullName) {
        this->fullName = fullName;
}

std::string BaseAcid::toString() const { return getFullName(); }
